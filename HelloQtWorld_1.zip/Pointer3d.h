#ifndef POINTER3D_H
#define	POINTER3D_H

#include "OglObj.h"

class Pointer3d : public  OglObj {
public:
    Pointer3d();
    Pointer3d(const Pointer3d& orig);
    virtual ~Pointer3d();
private:

};

#endif	/* POINTER3D_H */

